import React from "react";

const Footer = () => {
  return (
    <div className="h-36 bg-black text-white flex items-center justify-center">
      This is footer
    </div>
  );
};

export default Footer;
